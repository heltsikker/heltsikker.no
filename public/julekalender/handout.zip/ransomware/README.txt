                    !YOU HAVE BEEN PWNED!

                          uuuuuuu
                      uu$$$$$$$$$$$uu
                   uu$$$$$$$$$$$$$$$$$uu
                  u$$$$$$$$$$$$$$$$$$$$$u
                 u$$$$$$$$$$$$$$$$$$$$$$$u
                u$$$$$$$$$$$$$$$$$$$$$$$$$u
                u$$$$$$$$$$$$$$$$$$$$$$$$$u
                u$$$$$$"   "$$$"   "$$$$$$u
                "$$$$"      u$u       $$$$"
                 $$$u       u$u       u$$$
                 $$$u      u$$$u      u$$$
                  "$$$$uu$$$   $$$uu$$$$"
                   "$$$$$$$"   "$$$$$$$"
                     u$$$$$$$u$$$$$$$u
                      u$"$"$"$"$"$"$u
           uuu        $$u$ $ $ $ $u$$       uuu
          u$$$$        $$$$$u$u$u$$$       u$$$$
           $$$$$uu      "$$$$$$$$$"     uu$$$$$$
         u$$$$$$$$$$$uu    """""    uuuu$$$$$$$$$$
         $$$$"""$$$$$$$$$$uuu   uu$$$$$$$$$"""$$$"
          """      ""$$$$$$$$$$$uu ""$"""
                    uuuu ""$$$$$$$$$$uuu
           u$$$uuu$$$$$$$$$uu ""$$$$$$$$$$$uuu$$$
           $$$$$$$$$$""""           ""$$$$$$$$$$$"
            "$$$$$"                      ""$$$$""
              $$$"                         $$$$"

YOUR FILES HAVE BEEN ENCRYPTED WITH MILITARY GRADE ENCRYPTION
 IF YOU  WANT  YOUR  RECOVER  YOUR  FILES  YOU  HAVE  TO SEND
  $100 000 000   SCHMECKLES   TO   THE   SCHMECKLE   WALLET

"JbwHzedSF8XYRCUXEJBA8aa4GXSrQ4je5S2uWaHDbfToMbJKc3xEV9DcasA"

IF YOU DON'T SEND THE MONEY BEFORE 24. DECEMBER 17:00 YOUR
      FILES    WILL    BE    PERMANENTLY    LOST
