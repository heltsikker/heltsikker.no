@echo off
REM RB-7 Nightly maintenance script
echo Running diagnostics...
ping -n 1 192.168.1.42 >/dev/null
echo Checking ButlerLLM API status...
curl -s http://192.168.1.42:8080/health
echo Backup complete.
